document.getElementById("textChanger").onclick = function(){

	document.getElementById("inputText").innerHTML ="Hello to you too!"
}